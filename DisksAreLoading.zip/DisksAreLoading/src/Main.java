public class Main {
    public static void main(String[] args) {
        Circle one = new Circle();
        Circle two = new Circle(4);
        Circle three = new Circle(5, "Red");

        //ran in debugger to check
    }
}